object Utils {
  def sumar(a: Int, b: Int): Int = a + b
  def restar(a: Int, b: Int): Int = a - b
}
