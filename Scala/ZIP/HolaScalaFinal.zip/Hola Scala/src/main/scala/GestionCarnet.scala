import gestion.{ Carnet, Utils }

object GestionCarnet {
  def main(args: Array[String]): Unit = {
    val listaCarnets: List[Carnet] = List(Carnet("A1","Ana"),Carnet("A2","Pedro"), Carnet("A3", "Fernando"))

    /*
    for (c <- listaCarnets) {
      Utils.enviarCarnet(c)
    }
    */

    //for funcional (FP)
    listaCarnets.foreach((c) => Utils.enviarCarnet(c))
  }
}
