package gestion

object Utils {
  def enviarCarnet(c: Carnet) = {
    println(s"Enviando carnet con id ${c.id}")
  }
}
