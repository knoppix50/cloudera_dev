package gestion

case class Carnet(id: String, n: String)
