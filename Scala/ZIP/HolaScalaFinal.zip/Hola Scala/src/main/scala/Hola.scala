object Hola {
  def main(args: Array[String]): Unit = {

    //lambda o anomima
    //val multiplicar: (Int, Int) => Int = (x: Int,y: Int) => x * y
    val multiplicar = (x: Int,y: Int) => x * y
    val dividir: (Double, Double) => Double = (x: Double, y: Double) => x / y

    println("Hola desde Scala")

    val resultadoSumar = Utils.sumar(10,4)
    val resultadoRestar = Utils.restar(10,4)
    val resultadoMultiplicar = multiplicar(9,9)
    val resultadoDividir = dividir(10,3)

    println(mostrarInfo(resultadoSumar.toString))
    println(mostrarInfo(resultadoRestar.toString))
    println(mostrarInfo(resultadoMultiplicar.toString))
    println(mostrarInfo(resultadoDividir.toString))

    val items: List[Int] = List(1,2,3,4,5,6,7)
    val items100: List[Int] = (1 to 100).toList

    val nuevaListaMayores30 = items100.filter(item => item > 30)
    val itemsSumadosUnidad = items100.map(item => item + 1)

    for (item <- itemsSumadosUnidad) {
      print(item + " ")
    }


  }

  def mostrarInfo(info: String): String = s"Resultado:$info"




}
