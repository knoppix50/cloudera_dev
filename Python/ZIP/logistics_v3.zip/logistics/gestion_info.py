"""
import datetime (para la ej. opcional)
Nota: escribir como info, la fecha actual y la hora, minuto, segundo
"""

def escribir_log(info, severidad):
    #TODO: poner fecha (timestamp)
    f = None #variable local
    try:
        f = open('./data/incidencias.log','a')
        f.write(f"{severidad}*{info}\n")
    except FileNotFoundError as fex:
        print(fex)
    except:
        print("Error general al escribir log")
    finally:
        if f is not None:
            f.close()    

def leer_log() -> list:
    try:
        with open('./data/incidencias.log', 'r') as f:
            logs = f.readlines()
        
        return logs

    except FileNotFoundError as fex:
        print(fex)
        
    except:
        print("Error general en lectura de logs")
    
    return None #nulo en python
    



    