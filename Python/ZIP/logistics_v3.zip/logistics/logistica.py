#import destinos as dest
from destinos import esta_cerrado, denegar_recepcion
from gestion_info import escribir_log


def __ir_a_destino(destino):
    return True

def __entregar_paquetes(pqs, info_paquete):
    print("Numero paquetes a entregar", info_paquete[-1])
    es_no_entregable = esta_cerrado() or denegar_recepcion()
    print(f"No entregable:{es_no_entregable}")
    if not es_no_entregable:
        for i in range(info_paquete[-1]):
            del pqs[0]
        else:
            print("Paquetes tras el borrado:",pqs)
    else:
        #TODO:Revisar cuando no es posible la entrega, la lista de paquetes
        raise Exception("Imposible entrega por negocio cerrado o bien denegacion de entrega")

#[('AlCampo Gourmet', 1), ('El Corte Ingles', 3)]
def transportar_mercancias(paquetes, destinos_entregas):
    assert len(destinos_entregas) > 0, "Sin destinos ni entregas a los que llevar la mercancia"

    print("Paquetes al inicio:",paquetes)
    while len(destinos_entregas) > 0:
        if __ir_a_destino(destinos_entregas[0]): #primer destino
            try:
                __entregar_paquetes(paquetes,destinos_entregas[0])
                print("*Paquetes despues de entregar:",paquetes)
                #destinos_entregas.pop(0)
            except Exception as ex:
                desc = "Ver TODO"
                print(f"ID Paquete: {desc} -- {ex}")
                escribir_log(severidad=1,info=f"ID Paquete: {desc} -- {ex}")
                continue
            finally:
                destinos_entregas.pop(0)

    else:
        #print("Reparto concluido v1")
        print("Paquetes a la finalizacion:",paquetes)

    
    if len(destinos_entregas) == 0 and len(paquetes) == 0:
        print("Reparto concluido v2")
    else:
        print("Problemas en el reparto. LLamar a central.")
    
