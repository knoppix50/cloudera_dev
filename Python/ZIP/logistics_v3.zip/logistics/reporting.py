import gestion_info as g_inf

def leer_logs_entrega():
    
    def __mostrar_logs(l_logs):
        for log in l_logs:
            print(log.strip())
    
    logs = g_inf.leer_log()
    if logs is not None:
        __mostrar_logs(logs)