
diccionario = dict()

#creacion del dicionario
diccionario['python'] = 'Lenguaje de programacion que mola'
diccionario['java'] = 'Lenguaje de programacion que mola un poco menos que python'
diccionario['kotlin'] = 'Lenguaje de programacion que mola mucho'
diccionario['typescript'] = 'Lenguaje de programacion que es mejor que javascript'

""" try:
    opinion_kotlin = diccionario['kotlin']
    print(f"La opinion sobre kotlin de este usuario es {opinion_kotlin}")
except KeyError as kex:
    print(f"Error de lectura del diciconario:{kex}")
except:
    print("Error general de dicionario") """

#version 2
opinion_kotlin = diccionario.get('kotlin', None)
if opinion_kotlin is not None:
    #print(f"La opinion sobre kotlin de este usuario es {opinion_kotlin}")
    pass

#version 3
clave_a_buscar = 'kotlin'
if clave_a_buscar in diccionario:
    '''
    print(f"""La opinion sobre kotlin de
                este usuario es {diccionario[clave_a_buscar]}""")
    '''

    print("La opinion sobre kotlin de" \
            f"este usuario es {diccionario[clave_a_buscar]}")

    
def obtener_info_lenguaje(topic:str, dicc:dict) -> str:
    assert topic is not None, "No existe topic"

    if topic in dicc:
        return dicc[topic]
    else:
        return None

#preguntar al usuario por el topic
topic = input('Escriba topic (kotlin,python,java,typescript):')
try:
    hay_info = obtener_info_lenguaje(topic, diccionario)
    
    """ if hay_info:
        print(hay_info)
    else:
        print("Sin informacion sobre este topic") """
    print(hay_info if hay_info else "Sin informaci0n sobre este topic")

except AssertionError as aex:
    print(aex)

