import random
#type hint
def esta_cerrado() -> bool:
    return random.choice([True,False])

def denegar_recepcion() -> bool:
    return random.choice([True,False])