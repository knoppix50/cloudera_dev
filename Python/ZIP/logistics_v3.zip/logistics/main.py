import mercancias as merca
import logistica as log
from reporting import leer_logs_entrega


paquetes = list()


def empaquetar_mercancias(mercas):
    paquetes = []

    i = 0
    j = 5
    numero_paquetes = len(mercas) // 5
    for k in range(numero_paquetes):
        paquete = mercas[i:j]
        paquetes.append(paquete)
        #print(f"Paquete numero {k+1} ha sido procesado. Info {paquete}")
        
        i = i + 5
        j = j + 5
    
    return paquetes

if __name__ == "__main__":
    print(merca.cargar_mercancias()[-5:]) #printar las 5 primeras
    #empaquetar
    paqueteria = empaquetar_mercancias(merca.cargar_mercancias())
    
    destinos =  ['AlCampo Gourmet','El Corte Ingles']
    numero_entregas_destino = [1,3]

    destinos_num_entregas = list(zip(destinos, numero_entregas_destino))
    #print(destinos_num_entregas)
    
    log.transportar_mercancias(paqueteria, destinos_num_entregas)
    
    #reporting
    leer_logs_entrega()
    
