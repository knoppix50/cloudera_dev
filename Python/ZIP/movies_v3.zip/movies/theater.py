class Theater:

    @property
    def code(self):
        return self.__code

    @property
    def name(self):
        return self.__name

    def __init__(self, code, name):
        self.__code = code
        self.__name = name

