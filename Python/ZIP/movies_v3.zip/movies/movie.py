class Movie:

    @property
    def code(self):
        return self.__code

    @property
    def name(self):
        return self.__name

    @property
    def rating(self):
        return self.__rating

    @rating.setter
    def rating(self, new_rating):
        self.__rating = new_rating

    def __init__(self, code, name, rating):
        self.__code = code
        self.__name = name
        self.__rating = rating

    #sobre-escritura
    def __str__(self):
        return f"{self.__code} - {self.__name} - {self.__rating}"
