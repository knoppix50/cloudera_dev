
from alumno import Alumno
from examen import Examen
from clase import Clase

import datetime



def cargar_alumnos():
    """
    als = []
    als.append(Alumno("Pedro","Garcia", 5, 11))
    als.append(Alumno("Maria","Garcia", 5, 11))
    als.append(Alumno("Juan","Llopis", 6, 13))
    als.append(Alumno("Ines","Lucas", 5))
    als.append(Alumno("Javier","Lopez", 4, 10))
    
    return als
    """
    with open('alumnos.txt','r') as f:
        lineas = f.readlines()
        alumnos = [Alumno(*linea.split(',')) for linea in lineas[1:]]

    #print("Alumnos comprehension:",alumnos)
    return alumnos

def mostrar_alumnos(l_alumnos):
    for al in l_alumnos:
        print(al)

def calificar_alumno(al, notas, l_alumnos):
    if al is not None:
        for alumno in l_alumnos:
            if al.nombre == alumno.nombre:
                alumno.notas = notas #uso del setter
                break

def calificar_alumno_vfuncional(al, notas, l_alumnos):
    if al is not None:
        predicado = lambda alumno: alumno.nombre == al.nombre  
        lista_alumnos_encontrados = list(filter(predicado, l_alumnos))
        alumno_encontrado = lista_alumnos_encontrados[0] if lista_alumnos_encontrados else None
        if alumno_encontrado:
            alumno_encontrado.notas = notas

def crear_examenes():
        #crear examen (patron factoria)
        ex_filo = Examen.crear_examen("Filosofia",datetime.datetime.now())
        ex_mat = Examen.crear_examen("Mates",datetime.datetime.now())
        ex_lit = Examen.crear_examen("Literatura",datetime.datetime.now())

        return (ex_filo, ex_mat, ex_lit)

def realizar_evaluacion(al):
        try:
            ex_filosofia, ex_mates, ex_literatura = crear_examenes() #unpack
            al.hacer_examen(ex_filosofia)
            al.hacer_examen(ex_mates)
            al.hacer_examen(ex_literatura)
            #print(f"Las notas de {al.nombre } son {al.mostrar_notas()}")
            #print(f"Las media final de {al.nombre } es {al.obtener_media_total()}")
            return True
        except:
            return False

def evaluaciones_correctas(resultados_evaluacion) -> bool:
    return all(resultados_evaluacion)

        
if __name__ == "__main__":
    clase = None
    alumnos = None
    profesores = list()
    examenes = list()

    alumnos = cargar_alumnos()
    
    """
    for alumno in alumnos:
        realizar_evaluacion(alumno)
    """
    evaluaciones = [realizar_evaluacion(alumno) for alumno in alumnos]
    #print(evaluaciones)
    if evaluaciones_correctas(evaluaciones):
        #print("Todos los alumnos han sido evaluados")
        if len(alumnos) > 0:
            clase = Clase()
            #clase.anyadir_alumnos(*alumnos)
            pred_aprobado = lambda al: al.obtener_media_total() >= 5.0
            clase.anyadir_alumnos(*list(filter(pred_aprobado, alumnos)))
            if len(clase.alumnos) > 0:
                clase.mostrar_alumnos()
            else:
                print("No hay alumnos aprobados")
            pass
    else:
        print("Algun proceso de evaluacion ha fallado")
    
    #mostrar_alumnos(alumnos)
    
    


    
    



    #alumno realiza examen
    #ex_filosofia.hacer_examen()
    #print("Nota del examen de filosofia:",round(ex_filosofia.nota,2))
    
    #calificacion
    #calificar_alumno(alumnos[0],[1.4,7.5,8.4],alumnos)
    #alumno_no_existe = Alumno("Bernardo","Montes", 5, 12)
    #calificar_alumno_vfuncional(alumno_no_existe,[1.4,7.5,8.4],alumnos)

