class Examen:

    @property
    def nota(self):
        return self.__nota
    
    @property
    def tematica(self):
        return self.__tematica
    
    @property
    def fecha(self):
        return self.__fecha
    
    def __init__(self, tematica, fecha):
        self.__tematica = tematica 
        self.__fecha = fecha
        self.__nota = 0.0
    
    def hacer_examen(self):
        import random
        #self.__nota = random.random()*10
        self.__nota = 5
    
    def __str__(self):
        return f"<Tematica:{self.tematica},Fecha:{self.fecha}>"

    @classmethod
    def crear_examen(cls, tematica, fecha):
        return cls(tematica, fecha)
    

