#paradigma funcional python

#lista de numeros del 1 al 100
lista_100 = list(range(1,101)) #casting

def sumar_cinco_unidades(dato): #unico valor como parametro
    return dato + 5

"""a todos y cada uno de los elementos de lista_100
sumarle 5 unidades
"""

#version clasica
nueva_lista = []
for item in lista_100:
    nueva_lista.append(sumar_cinco_unidades(item))
else:
    #print(nueva_lista)
    pass

#version funcional
nueva_lista_funcional = list(map(sumar_cinco_unidades, lista_100))
#print(nueva_lista_funcional)

#funciones lambda (anonimas)
restar_unidad = lambda x: x - 1
nueva_lista_resta1 = list(map(restar_unidad, lista_100))
"""
for item in nueva_lista_resta1:
    print("Desde list:",item)

for item in map(restar_unidad, lista_100):
    print("Desde map:",item)
"""

"""
#uso directo de la lambda
for item in map(lambda x: x - 1, lista_100):
    print("Desla lambda:",item)
"""

#filtrado de datos
predicado = lambda x: x > 10 and x < 50
numeros_mayores_10_menores_50 = list(filter(predicado ,lista_100))
#print(numeros_mayores_10_menores_50)

#numeros_mayores_10_menores_50 realizar la raiz cuadrada (math)
import math 
lista_raiz_cuadrada = list(map(math.sqrt,filter(predicado ,lista_100)))
print(lista_raiz_cuadrada)

#print(round(12.898989,2))
#print(list(map(round, lista_raiz_cuadrada)))
print(list(map(lambda x: round(x,2), lista_raiz_cuadrada)))





items = list(range(90))
print(items)
items_mas_uno = list(map(lambda item: item + 1, items))
print(items_mas_uno)

#comprehension list
def sumar_uno(num):
    return num + 1
items_mas_uno_cl = [sumar_uno(item) for item in items if item > 25]
print("Comprehension list:", items_mas_uno_cl)



#intento de convertor def a lambda
def operar_suma(num):
    if num % 2 != 0:
            num += 1   
    else:
        num += 2
    
    return num

def sumar(lista):
    nueva_lista = []
    for num in lista:
        if num % 2 != 0:
            num+=1   
        else:
            num+=2
        nueva_lista.append(num)

    return nueva_lista

sumar_v2 = lambda lista: [operar_suma(num) for num in lista]

print(sumar([1,2,3,4]))
print('*' * 60)
print(sumar_v2([1,2,3,4]))


#unpackaging
a,_,c = (1,2,3)
print(a)
print(c)

x,y,z,r = [100,200,300,400]
print(z)

def procesar(a,b,c,d):
    print(d)

procesar(*[100,200,300,400])

data = (1,2,3,4,5,5,5,5,5,5)
conjunto_tupla = set(data)
print(tuple(conjunto_tupla))

info = tuple([1,2,3,4,5])
print("Info:", info)

data = ['1','2','3','4','5','6','7']
#"1,2,3,4,5,6,7"
print("*".join(data))



#lista cremallera
lista1 = [1,3,5]
lista2 = [2,4,6]

#lista3 = [1,2,3,4,5,6]
lista1.extend(lista2)
print(lista1)
print(sorted(lista1))

lista1 = [1,3,5]
lista2 = ['a','b','c']

#lista3 = [1,'a',3,'b',5,'c']
lista3 = []
for i in range(len(lista1)):
    lista3.append(lista1[i])
    lista3.append(lista2[i])

print(lista3)

    
