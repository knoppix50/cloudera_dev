package com.sepe;

public enum Tematica {
    BIG_DATA,
    PYTHON,
    CIENCIA_DATOS,
    CLOUD,
    IoT,
    CIBERSEGURIDAD
}
