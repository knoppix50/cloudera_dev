package com.sepe;

public class Persona {
    private String nombre;

    public String getNombre() {
        return nombre;
    }

    public Persona(String nombre) {
        this.nombre = nombre;
    }
}
