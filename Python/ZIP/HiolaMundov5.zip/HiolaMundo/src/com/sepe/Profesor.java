package com.sepe;

public class Profesor extends Persona {

    private Tematica tematica;

    public Profesor(String nombre) {
        super(nombre);
    }

    //comportamiento
    public void corregir() {

    }
}
