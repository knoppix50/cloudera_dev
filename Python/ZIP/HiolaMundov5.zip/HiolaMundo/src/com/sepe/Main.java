package com.sepe;

import java.util.ArrayList;
import java.util.List;

public class Main {

    //atributos
    //declarar aula; inicializar aula
    private Aula aula = new Aula(Tematica.BIG_DATA);

    //getter
    public Aula getAula() {
        return aula;
    }

    public static void main(String[] args) {
        String[] nombres = {"Miguel", "Sonia", "Berta", "Juan", "Jaime"};

        System.out.println("Gestion Academica");
        Main app = new Main(); //instanciar un objeto llamado app de la clase Main

        //anyadir varios alumnos y alumnas
        app.cargarAlumnos(nombres);

        //listar alumnos
        app.mostrarAlumnos(app.getAula());

        //mostrar nota media del aula
        System.out.println("Media aula:" + app.obtenerMediaAula());

        //creacion del centro educativo (solo una instancia)
        CentroEducativo pue = new CentroEducativo("Proyecto Universidad Empresa", TipoCentro.TECNOLOGICO);
        Alumno miguel = app.getAula().getAlumnos().get(0);
        if (pue.admitirAlumno(miguel)) {
            System.out.println("Alumno admitido");
            pue.asignarAlumno(miguel);
        } else {
            System.out.println("Lo sentimos pero este alumno no ha sido admitido");
        }

    }

    private boolean cargarAlumnos(String[] lista) {
        try {
            for (int i = 0; i < lista.length; i++) {
                Alumno al = new Alumno(lista[i], Tematica.PYTHON);
                anyadirAlumno(al, aula);
            }
            return true;
        } catch (Exception ex) {
            return false;
        }

    }

    //metodo no estatico para anyadir un alumno
    private void anyadirAlumno(Alumno al, Aula a) {
        a.anyadirAlumno(al);
    }

    private void mostrarAlumnos(Aula aula) {
        aula.mostrarAlumnos();


    }

    public float obtenerMediaAula() {
        //llamadas delegadas
        return this.aula.obtenerNotaMedia();
    }

}
