package com.sepe;

import java.util.ArrayList;
import java.util.List;

public class Alumno extends Persona {

    private String nombre;
    private float notaFinal;
    private List<Asignatura> asignaturas;
    private Tematica tematicaEstudio;
    private float[] expedienteAcademico = new float[]{6.5f,8.9f,3.7f,8.5f};

    public float[] getExpedienteAcademico() {
        return expedienteAcademico;
    }


    public String getNombre() {
        return nombre;
    }


    //getter
    public float getNotaFinal() {
        return notaFinal;
    }

    //setter
    public void setNotaFinal(float notaFinal) {
        this.notaFinal = notaFinal;
    }

    public Tematica getTematicaEstudio() {
        return tematicaEstudio;
    }

    //constructor
    public Alumno(String nombre, Tematica tem) {
        super(nombre);
        this.nombre = nombre;
        this.tematicaEstudio = tem;
    }

    public void crearAsignaturas(/*Tematica tematica*/) {
        //TODO:realizar el codigo de creacion de asignatura
        List<Asignatura> asigs = new ArrayList<>();
        switch (this.tematicaEstudio) {
            case BIG_DATA:
                asigs.add(new Asignatura("Spark"));
                asigs.add(new Asignatura("Algebra"));
                break;
            case PYTHON:
                asigs.add(new Asignatura("POO"));
                asigs.add(new Asignatura("Variables y Funciones"));
                break;
            case CIENCIA_DATOS:
                break;
            case CIBERSEGURIDAD:
                break;
            case CLOUD:
                break;
            default:
        }
        this.asignaturas = asigs;
    }

    private class Asignatura {
        private String nombre;
        private float nota;

        public String getNombre() {
            return nombre;
        }

        public float getNota() {
            return nota;
        }

        public Asignatura(String nombre) {
            this.nombre = nombre;
        }

        public void setNota(float nota) {
            this.nota = nota;
        }
    }
}
