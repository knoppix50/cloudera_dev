package com.sepe;

public enum TipoCentro {
    GENERALISTA,
    TECNOLOGICO,
    HUMANISTICO
}
