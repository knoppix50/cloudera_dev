import sys

import ciudades as c

def recoger_info_ciudades(ciudades):
    """Funcion que muestra la seccion de parametros relativa ala ciudades"""
    for ciudad in ciudades:
        print(ciudad)

def tratar_parametro_ciudades(info):
    data = None
    if info is not None and len(info) > 0:
        data = info.split("*")
    
    return data 

if __name__ == "__main__":
    print("Este es el programa principal / punto de entrada")

    lista_ciudades = list() #[]

    #recogida de ciudades
    ciudades = tratar_parametro_ciudades(sys.argv[2])
    c.cargar_ciudades(lista_ciudades, ciudades)
    #recogida parametro
    ciudades = c.obtener_ciudades_con_datos_de_poblacion(lista_ciudades)
    interruptor = int(sys.argv[1])
    #gestion del valor del parametro
    if interruptor == 1:
        c.mostrar_ciudades(ciudades)