"""Dado una lista de elementos del 1 al 400, sumar una unidad a los impares 
y dos unidades a los pares. 
Utilizamos por lo menos una vez una función lambda. 
Utilizamos también las funciones map/filter cuando sea necesario. 
La lista resultante la invertimos y obtenemos el primer elemento tras la 
inversion"""

# Crear lista 1 a 400
lista_400 = list(range(1,401))
print(f"Lista original a operar  {lista_400}")
print("*" * 60)

"""Operar ista de impares"""

suma1_impar = lambda x: x + 1
impares = list(map(suma1_impar, lista_400)) 
print("*" * 50 )
print(f"Lista de impares operada {impares}")
print("*" * 50)
 
"""Operar lista de pares"""
sumar2_par = lambda x: x+2 

pares = list(map(sumar2_par,lista_400)) 
 
print(f"Lista de pares operada {pares}")
print("*" * 50)
lista_final= list()




lista_final = list(zip(impares, pares))
print("*" * 50)


lista_final_total = list()

for indice in range(0, len(pares)):
    if (indice +2) % 2==0:
        lista_final_total.append(impares[indice])
      
    if (indice +2) % 2 != 0:
        lista_final_total.append(pares[indice])
    
print(f"Lista final total operada {lista_final_total}")     


lista_final_total_invertida =  reversed(lista_final_total)
lisinv=list(reversed(lista_final_total))

print(f"La lista final invertida es: {lisinv}")
 
print("*" * 25)

print(f"El primer numero de la lista final invertida es: {lisinv[0]}")

