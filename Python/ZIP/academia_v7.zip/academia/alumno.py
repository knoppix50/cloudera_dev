class Alumno:

    #atributos

    #propiedades
    @property
    def nombre(self):
        return self.__nombre
    
    @property
    def examenes(self):
        return self.__examenes
    
    @property
    def notas(self): #getter
        return self.__notas

    @notas.setter
    def notas(self, l_notas): #setter
        self.__notas = l_notas

    #constructor
    def __init__(self, nombre, apellido, curso, edad = 12):
        self.__nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.curso = curso
        self.__notas = list() #atributo privado
        self.__examenes = list()

    
    def hacer_examen(self, examen):
        if examen is not None:
            examen.hacer_examen() #llamada delegada
            self.__examenes.append(examen)
            self.__notas.append(examen.nota)
    
    def mostrar_notas(self):
        """
        for examen in self.__examenes:
            self.__notas.append(examen.nota)
        """
        return self.__notas #lista de notas
    
    def obtener_media_total(self):
        return sum(self.__notas)/len(self.__notas)

    

    #sobre-escritura
    def __str__(self):
        return f"Hola me llamo {self.nombre} {self.apellido} y tengo {self.edad} anyos."
