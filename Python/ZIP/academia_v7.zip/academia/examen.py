from documento import Documento

class Examen(Documento):

    @property
    def nota(self):
        return self.__nota
    
    @property
    def tematica(self):
        return self.__tematica
    
    @property
    def fecha(self):
        return self.__fecha
    
    def __init__(self, tematica, fecha, titulo, autor, contenido):
        super().__init__(titulo, autor, contenido )
        self.__tematica = tematica 
        self.__fecha = fecha
        self.__nota = 0.0
    
    def hacer_examen(self):
        import random
        #self.__nota = random.random()*10
        self.__nota = 5
    
    def __str__(self):
        return f"<Tematica:{self.tematica},Fecha:{self.fecha}>"

    @classmethod
    def crear_examen(cls, tematica, fecha, titulo = "Titulo general", autor = "Direccion", contenido_general = "Normativa"):
        return cls(tematica, fecha, titulo, autor, contenido_general)
    

