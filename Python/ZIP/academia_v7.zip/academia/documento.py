class Documento:


    @property
    def titulo(self):
        return self.__titulo
    
    @property
    def autor(self):
        return self.__autor

    @property
    def contenido(self):
        return self.__contenido

    def __init__(self, titulo, autor, contenido):

        self.__titulo = titulo
        self.__autor = autor
        self.__contenido = contenido #comun a cualquier doc. de la academia

    
    def guardar():
        pass

    def cargar():
        pass

    def imprimir():
        pass
