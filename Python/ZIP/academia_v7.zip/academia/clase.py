class Clase:
    
    @property
    def alumnos(self):
        return self.__alumnos
    
    def __init__(self):
        self.__alumnos = list()

    def anyadir_alumno(self, al):
        assert al is not None, "No hay alumno para anyadir"
        self.__alumnos.append(al)
    
    def anyadir_alumnos(self, *als): #varargs
        if als is not None and len(als) > 0:
            for al in als:
                self.anyadir_alumno(al)
    
    def eliminar_alumno(self, al):
        assert al is not None, "No hay alumno para eliminar"
    
    def mostrar_alumnos(self):
        for al in self.__alumnos:
            print(al)

    
