import mysql.connector as conn

connection = None #variable global
"""
Una funcion que reciba un rating R y devuelva las peliculas quer tienen ese rating

"""

def conectar_base_datos(host, user, password, database):
    global connection
    connection = conn.connect(host=host, user=user, password=password, database=database)
    #return mydb

def obtener_peliculas_por_rating(rating = "G"):
    global connection
    sql_sentence = f"select * from movies where rating = '{rating}'"
    mycursor = connection.cursor()
    mycursor.execute(sql_sentence)
    pelis = mycursor.fetchall() #obtencion de una lista
    return pelis

def validar_entrada(rate):
    return rate in ('G', None, 'NC-17','PG-13','PG')

def obtener_peliculas(rate = None):
    global connection
    rate = None if rate == '' else rate
    assert validar_entrada(rate), "Entrada invalida"

    mycursor = connection.cursor()
    sql_sentence = f"select * from movies"
    sql_sentence = sql_sentence + (f" where rating='{rate}'" if rate is not None else "")
    mycursor.execute(sql_sentence)
    pelis = mycursor.fetchall() #obtencion de una lista
    return pelis

def mostrar_peliculas(lista):
    for peli in lista:
        print(peli)


if __name__ == "__main__":
    print('Init movies')
    info = {
        "host": "localhost",
        "user": "operator1",
        "password": "pue",
        "database": "movie"
    }
    """
    conn = conectar_base_datos(**info)
    peliculas = obtener_peliculas(conn)
    mostrar_peliculas(peliculas)
    """


    try:
        conectar_base_datos(**info)
        #mostrar_peliculas(obtener_peliculas())
        mostrar_peliculas(obtener_peliculas(input("Que rating quiere susar para as peliculas?(Todas si no hay respuesta)").strip()))
    except AssertionError as asex:
        print(asex)
    except:
        print("Error general")
    finally:
        if connection is not None:
            connection.close()




