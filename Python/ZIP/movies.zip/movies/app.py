import mysql.connector as conn

connection = None #variable global
"""
Una funcion que reciba un rating R y devuelva las peliculas quer tienen ese rating

"""

def obtener_peliculas_por_rating(rating = "G"):
    global connection
    sql_sentence = f"select * from movies where rating = '{rating}'"
    mycursor = connection.cursor()
    mycursor.execute(sql_sentence)
    pelis = mycursor.fetchall() #obtencion de una lista
    return pelis

def conectar_base_datos(host, user, password, database):
    global connection
    connection = conn.connect(host=host, user=user, password=password, database=database)
    #return mydb

def obtener_peliculas():
    global connection
    mycursor = connection.cursor()
    mycursor.execute("select * from movies")
    pelis = mycursor.fetchall() #obtencion de una lista
    return pelis

def mostrar_peliculas(pelis):
    for peli in pelis:
        print(peli)


if __name__ == "__main__":
    print('Init movies')
    info = {
        "host": "localhost",
        "user": "operator1",
        "password": "pue",
        "database": "movie"
    }
    """
    conn = conectar_base_datos(**info)
    peliculas = obtener_peliculas(conn)
    mostrar_peliculas(peliculas)
    """
    conectar_base_datos(**info)
    mostrar_peliculas(obtener_peliculas())

    try:
        mostrar_peliculas(obtener_peliculas_por_rating(input("Que rating quiere susar para as peliculas?")))
    except:
        print("Entrada invalida")
    if connection is not None:
        connection.close()




