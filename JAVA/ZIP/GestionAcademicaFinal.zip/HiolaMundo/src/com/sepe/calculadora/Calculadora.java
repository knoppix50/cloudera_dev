package com.sepe.calculadora;

public class Calculadora {

    //comportamiento: suma y division

    public float sumar(float op1, float op2) {
        return op1 + op2;
    }

    public float dividir(float op1, float op2) {
        return op1 / op2;
    }

}
